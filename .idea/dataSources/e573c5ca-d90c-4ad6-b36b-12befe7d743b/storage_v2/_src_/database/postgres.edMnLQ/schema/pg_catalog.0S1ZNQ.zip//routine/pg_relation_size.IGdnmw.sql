create function pg_relation_size(regclass) returns bigint
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function pg_relation_size(regclass, text) is 'disk space usage for the main fork of the specified table or index';

alter function pg_relation_size(regclass, text) owner to postgres;

